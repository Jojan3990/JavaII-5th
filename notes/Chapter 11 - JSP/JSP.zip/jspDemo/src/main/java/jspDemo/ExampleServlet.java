package jspDemo;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ExampleServlet extends HttpServlet {

	String name ="Sudip";
	
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
		this.name = this.name.toUpperCase();
		PrintWriter out = res.getWriter();
		out.print(name);
		
	}
}
